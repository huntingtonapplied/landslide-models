---
craft_id: landslide_terrain_deformation_v1
version: 0.2.0
project: landslide
license: Apache-2.0
tags: ['status:trained', 'project:landslide', 'provenance:synthetic_analytic', 'release_metric:disp_skill_vs_zero']
library_name: landslide-models
---

# landslide_terrain_deformation_v1

**Project:** landslide · **Version:** 0.2.0 · **License:** Apache-2.0
**Produced by:** [Intel — Universal ML Inference Engine](https://huntingtonai.com)

> Landslide Terrain Deformation Predictor Craft (3.4)

> ⚠️ **Synthetic / non-engine-truth data (`synthetic_analytic`).** The metrics below are
> **NOT** the real simulation engine's output — they are computed on the craft's synthetic
> or cited training distribution. The headline number is the **`disp_skill_vs_zero`** metric, not an
> engine-faithful accuracy; read it as such.
>
> _Eval note:_ IMPROVED skill_vs_mean 0.083->0.124 (+50%). Root cause was not "hard problem" but (a) a BIMODAL corpus (42% dead-stable runs) -> rebalanced into failing/marginal/stable regimes, and (b) FEATURE INSUFFICIENCY: the displacement direction n_down=-grad(z)/|grad(z)| was absent from node_features so the model could predict failure LOCATION (acc 0.82) but not the displacement VECTOR -> added it (node_feature_dim 10->12). An active-node PHYSICAL metric (active_skill_vs_mean, active_rel_l2) now steers magnitude honestly (still under-predicts magnitude — a shallow-GNN capacity limit, not data). synthetic_analytic label provenance.

## Model description

`landslide_terrain_deformation_v1` is a **surrogate model** ("craft") used by the Intel inference
engine to replace expensive numerical simulation with fast neural inference.
Output kind: **fields** (0 outputs). Landslide Terrain Deformation Predictor Craft (3.4)

- **Status:** trained
- **Type:** neural inference surrogate (physics-trained)
- **Parameters:** 102,276
- **Weights format:** `model.safetensors` (float32)
- **Device family:** `—`

## Intended use

Drop-in inference surrogate for landslide. You provide a physical **device
specification** (geometry, materials, doping, operating point); the package
returns the physical output channels below. The device→model featurization and
de-normalization are handled inside the package. Not intended for regimes
outside its training domain (below).

## Inputs & outputs

**Input — physical device specification** (`input.kind: device_spec`):

Provide a physical device/scene specification; see the project's model docs.

The internal encoding (how the device becomes model inputs) and the normalization are handled **inside the package** — you never build feature vectors by hand.

**Output — physical fields:**

| | |
|---|---|
| **Output channels** | 0 |
| **Parameters** | 102,276 |

## Training domain / compatibility

| Property | Value |
|---|---|
| Solution type | `—` |
| Physics models | — |
| Temperature | — K |
| Bias range (Vds) | — |
| Tags | `status:trained`, `project:landslide`, `provenance:synthetic_analytic`, `release_metric:disp_skill_vs_zero` |

## Training data

Trained on landslide simulation output for the `—` solution regime (physics models: see config). Labels derive from the numerical landslide engine / reference closed-forms; the data-generation pipeline is proprietary.

## Limitations & out-of-scope use

- **Do not** use outside the training domain above (solution type, temperature, bias range) — accuracy degrades with no guarantee.
- This is a **surrogate**, not the ground-truth solver: treat outputs as fast approximations; validate against the numerical engine where correctness is critical.
- Output kind is **fields** — consuming code must match the documented I/O contract exactly.


## Evaluation

| Metric | Value |
|---|---|
| **Held-out accuracy** | 0.1249 |
| Best validation loss | 0.137155576476029 |

_**Held-out accuracy** is an independent benchmark (`offline_eval` on a held-out set); the loss rows are the model's own recorded train/val losses. See `config.json → metrics` for the machine-readable copy._

## Caveats & recommendations

- An independent **held-out** benchmark is reported (Held-out accuracy, via `offline_eval`); the loss rows remain the model's own recorded train/val losses.
- Verify integrity before use: `shasum -a 256 -c SHA256SUMS` (or `sha256sum -c SHA256SUMS` on Linux). Weights are `safetensors` — safe to load, no pickle.
- This is a **surrogate**, not the ground-truth solver — validate against the numerical engine where correctness is critical.

## Usage

Install the inference package and run it on a physical device spec — it fetches the
weights, builds the model, and returns physical fields (no PyTorch required):

```bash
pip install landslide-models
```

```python
from landslide_models import load

model = load("landslide_terrain_deformation_v1")           # pulls + verifies weights, builds the compiled pipeline
fields = model.predict(device_spec)  # physical device in -> physical fields out
```

`device_spec` is the physical device specification documented under **Inputs & outputs**
above. Featurization and de-normalization happen inside the package.

## Provenance

- **Author:** sim-train release (landslide, engine-driven generators)
- **Trained:** 2026-07-19T21:19:17.769374+00:00
- **Source checksum (runtime .pt):** `0aee7a460d9364bba955ad5c9ddc381dfb9379864c3d2dfae8c97178e6436eb8`

## Citation

```bibtex
@software{landslide_terrain_deformation_v1_0_2_0,
  title  = {landslide_terrain_deformation_v1},
  author = {Landslide},
  year   = {2026},
  note   = {Version 0.2.0},
  url    = {https://downloads.landslide.global/models/landslide_terrain_deformation_v1/0.2.0/}
}
```

## License

Licensed under the **Apache-2.0** (Apache-2.0) — free to use for
inference; redistribution and reverse engineering of the compiled inference core
are not permitted. See `LICENSE`.
